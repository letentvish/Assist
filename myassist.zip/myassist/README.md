# AI Assistant Android App

A comprehensive AI assistant app with multi-LLM support and full system access capabilities.

## Features

### 🤖 Multi-LLM Integration
- **OpenAI GPT** - Advanced conversational AI
- **Anthropic Claude** - Ethical AI with strong reasoning
- **Google Gemini** - Multimodal AI capabilities
- **Perplexity AI** - Real-time web search integration
- **Ensemble Mode** - Combines multiple LLMs for better responses

### 🎤 Voice Interface
- Speech-to-text input
- Text-to-speech output
- Continuous voice detection
- Wake word activation (configurable)

### 📱 System Access & Automation
- **Accessibility Service** - Full app control and automation
- **Phone Functions** - Make calls, send SMS, manage contacts
- **System Settings** - Change device settings, toggle features
- **App Control** - Open, close, and interact with any app
- **Gesture Automation** - Perform taps, swipes, and complex gestures
- **Notification Management** - Read and respond to notifications

### 🎨 Customization
- **Dynamic Themes** - Light, Dark, and Blue themes
- **Runtime Code Modification** - Add features through AI
- **API Configuration** - Easy setup for multiple AI services
- **Voice Settings** - Adjustable speech rate and voice options

## Setup Instructions

### 1. API Keys Configuration
1. Open the app and go to Settings (⚙️)
2. Enter your API keys for the AI services you want to use:
   - OpenAI: Get from https://platform.openai.com/api-keys
   - Anthropic: Get from https://console.anthropic.com/
   - Google AI: Get from https://makersuite.google.com/app/apikey
   - Perplexity: Get from https://www.perplexity.ai/settings/api

### 2. System Permissions
The app requires several permissions for full functionality:

#### Required Permissions:
- **Microphone** - For voice input
- **Phone** - To make calls and read phone state
- **Contacts** - To access and manage contacts
- **SMS** - To send and read text messages
- **Location** - For location-based services
- **Storage** - To access files and media
- **System Alert Window** - For overlay features

#### Accessibility Service:
1. Go to Settings > Accessibility
2. Find "AI Assistant Service"
3. Enable the service
4. Grant permission to control your device

### 3. Building the App

```bash
# Clone or download the project
cd myassist

# Build the APK
./gradlew assembleDebug

# Install on device
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Usage Examples

### Voice Commands
- "Call John Smith"
- "Send a text to Mom saying I'll be late"
- "Open WhatsApp"
- "Set an alarm for 7 AM"
- "Take a screenshot"
- "Turn on WiFi"
- "Search for restaurants near me"

### Chat Interface
- Type any question or request
- Get responses from multiple AI models
- View conversation history
- Switch between different AI providers

### System Automation
- "Open Settings and turn on Bluetooth"
- "Navigate to the camera app and take a photo"
- "Read my latest notifications"
- "Close all running apps"

## Architecture

```
├── ai/                     # AI integration layer
│   ├── LLMManager.kt      # Manages multiple AI providers
│   ├── providers/         # Individual AI service implementations
│   └── models/           # Data models for AI interactions
├── speech/               # Voice processing
│   └── SpeechManager.kt  # Speech-to-text and text-to-speech
├── services/            # Background services
│   ├── VoiceAssistantService.kt      # Voice detection service
│   └── AssistantAccessibilityService.kt  # System automation
└── viewmodels/          # UI logic and state management
    └── AssistantViewModel.kt
```

## Security & Privacy

- API keys are stored securely using Android Keystore
- All system access requires explicit user permission
- Voice data is processed locally when possible
- Conversation history can be cleared at any time
- No data is shared without user consent

## Extending the App

### Adding New AI Providers
1. Create a new provider class extending `BaseProvider`
2. Implement the `generateResponse` method
3. Add the provider to `LLMManager`
4. Update the settings UI

### Adding New System Commands
1. Add command parsing logic to `SystemCommandExecutor`
2. Implement the command execution method
3. Add accessibility service interactions if needed

### Custom Themes
1. Create new theme in `res/values/themes.xml`
2. Add theme option to settings
3. Update theme selection logic

## Troubleshooting

### Common Issues
1. **Voice not working** - Check microphone permissions
2. **Can't control apps** - Enable accessibility service
3. **API errors** - Verify API keys are correct
4. **Permissions denied** - Grant all required permissions in settings

### Debug Mode
Enable debug logging in the app settings to see detailed error messages and API responses.

## Contributing

This is a personal project, but feel free to fork and modify for your own use. The modular architecture makes it easy to add new features and AI providers.

## License

This project is for personal use. Make sure to comply with the terms of service of the AI providers you use.