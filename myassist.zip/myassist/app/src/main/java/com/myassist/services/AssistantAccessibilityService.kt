package com.myassist.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AssistantAccessibilityService : AccessibilityService() {
    
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.let {
            when (it.eventType) {
                AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                    handleNotification(it)
                }
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                    handleWindowChange(it)
                }
            }
        }
    }
    
    override fun onInterrupt() {
        // Handle interruption
    }
    
    fun performClick(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()
        
        dispatchGesture(gesture, null, null)
    }
    
    fun performSwipe(startX: Float, startY: Float, endX: Float, endY: Float) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 500))
            .build()
        
        dispatchGesture(gesture, null, null)
    }
    
    fun findAndClickButton(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val button = findNodeByText(rootNode, text)
        return button?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }
    
    fun enterText(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val editText = findEditableNode(rootNode)
        return editText?.let {
            val arguments = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            it.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
        } ?: false
    }
    
    private fun findNodeByText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        if (node.text?.toString()?.contains(text, ignoreCase = true) == true) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val result = findNodeByText(child, text)
            if (result != null) return result
        }
        return null
    }
    
    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val result = findEditableNode(child)
            if (result != null) return result
        }
        return null
    }
    
    private fun handleNotification(event: AccessibilityEvent) {
        // Handle notifications for AI processing
        val notification = event.text?.joinToString(" ") ?: ""
        // Send to AI for processing
    }
    
    private fun handleWindowChange(event: AccessibilityEvent) {
        // Handle window changes
        val packageName = event.packageName?.toString() ?: ""
        // Track app usage for AI context
    }
}