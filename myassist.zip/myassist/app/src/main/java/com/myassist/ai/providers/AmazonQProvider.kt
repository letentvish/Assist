package com.myassist.ai.providers

import com.myassist.ai.models.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class AmazonQProvider : BaseProvider() {
    
    private val client = OkHttpClient()
    private val JSON = "application/json; charset=utf-8".toMediaType()
    
    override suspend fun generateResponse(message: String, history: List<ChatMessage>): String {
        return withContext(Dispatchers.IO) {
            try {
                val requestBody = buildRequestBody(message, history)
                val request = Request.Builder()
                    .url("https://q.us-east-1.amazonaws.com/api/v1/conversations")
                    .post(requestBody)
                    .addHeader("Authorization", "Bearer ${getApiKey()}")
                    .addHeader("Content-Type", "application/json")
                    .build()
                
                val response = client.newCall(request).execute()
                parseResponse(response.body?.string() ?: "")
            } catch (e: Exception) {
                "Amazon Q error: ${e.message}"
            }
        }
    }
    
    private fun buildRequestBody(message: String, history: List<ChatMessage>): RequestBody {
        val json = JSONObject().apply {
            put("message", message)
            put("conversationId", "mobile-assistant")
            put("parentMessageId", System.currentTimeMillis().toString())
            
            if (history.isNotEmpty()) {
                val context = JSONArray()
                history.takeLast(5).forEach { msg ->
                    context.put(JSONObject().apply {
                        put("role", msg.role)
                        put("content", msg.content)
                    })
                }
                put("context", context)
            }
        }
        return json.toString().toRequestBody(JSON)
    }
    
    private fun parseResponse(responseBody: String): String {
        return try {
            val json = JSONObject(responseBody)
            json.optString("message", "No response from Amazon Q")
        } catch (e: Exception) {
            "Failed to parse Amazon Q response"
        }
    }
    
    private fun getApiKey(): String {
        // Get from secure storage - implement based on your preference storage
        return "your-amazon-q-api-key"
    }
    
    override fun isConfigured(): Boolean {
        return getApiKey().isNotEmpty() && getApiKey() != "your-amazon-q-api-key"
    }
}