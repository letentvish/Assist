package com.myassist.ai.models

data class ChatMessage(
    val role: String,
    val content: String,
    val timestamp: Long
)

data class LLMConfig(
    val name: String,
    val apiKey: String,
    val baseUrl: String,
    val model: String,
    val enabled: Boolean = true,
    val priority: Int = 1
)

data class SystemCommand(
    val action: String,
    val target: String,
    val parameters: Map<String, Any> = emptyMap()
)