package com.myassist.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.myassist.ai.LLMManager
import com.myassist.ai.models.ChatMessage
import com.myassist.speech.SpeechManager
import kotlinx.coroutines.launch

class AssistantViewModel(application: Application) : AndroidViewModel(application) {
    
    private val llmManager = LLMManager()
    private val speechManager = SpeechManager(application)
    
    private val _assistantResponse = MutableLiveData<String>()
    val assistantResponse: LiveData<String> = _assistantResponse
    
    private val _isListening = MutableLiveData<Boolean>()
    val isListening: LiveData<Boolean> = _isListening
    
    private val _chatHistory = MutableLiveData<List<ChatMessage>>()
    val chatHistory: LiveData<List<ChatMessage>> = _chatHistory
    
    private val conversationHistory = mutableListOf<ChatMessage>()
    
    fun sendMessage(message: String) {
        viewModelScope.launch {
            try {
                val userMessage = ChatMessage("user", message, System.currentTimeMillis())
                conversationHistory.add(userMessage)
                updateChatHistory()
                
                val response = llmManager.getEnsembleResponse(message, conversationHistory)
                
                val aiMessage = ChatMessage("assistant", response, System.currentTimeMillis())
                conversationHistory.add(aiMessage)
                updateChatHistory()
                
                _assistantResponse.value = response
                speechManager.speak(response)
                
            } catch (e: Exception) {
                _assistantResponse.value = "Error: ${e.message}"
            }
        }
    }
    
    fun startVoiceInput() {
        _isListening.value = true
        speechManager.startListening { recognizedText ->
            _isListening.value = false
            if (recognizedText.isNotEmpty()) {
                sendMessage(recognizedText)
            }
        }
    }
    
    private fun updateChatHistory() {
        _chatHistory.value = conversationHistory.toList()
    }
    
    fun clearHistory() {
        conversationHistory.clear()
        updateChatHistory()
    }
}