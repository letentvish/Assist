package com.myassist

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.myassist.databinding.ActivityMainBinding
import com.myassist.services.VoiceAssistantService
import com.myassist.viewmodels.AssistantViewModel

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: AssistantViewModel
    
    private val PERMISSION_REQUEST_CODE = 1001
    private val requiredPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.SYSTEM_ALERT_WINDOW,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.READ_CALENDAR,
        Manifest.permission.SEND_SMS
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        viewModel = ViewModelProvider(this)[AssistantViewModel::class.java]
        
        setupUI()
        requestPermissions()
        startVoiceService()
    }
    
    private fun setupUI() {
        binding.apply {
            btnSendMessage.setOnClickListener {
                val message = etMessage.text.toString()
                if (message.isNotEmpty()) {
                    viewModel.sendMessage(message)
                    etMessage.text.clear()
                }
            }
            
            btnVoiceInput.setOnClickListener {
                viewModel.startVoiceInput()
            }
            
            btnSettings.setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        }
        
        // Observe responses
        viewModel.assistantResponse.observe(this) { response ->
            binding.tvResponse.text = response
        }
        
        viewModel.isListening.observe(this) { listening ->
            binding.btnVoiceInput.text = if (listening) "Listening..." else "Voice Input"
        }
    }
    
    private fun requestPermissions() {
        val missingPermissions = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        
        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missingPermissions.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
        
        // Request accessibility service
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            startActivity(intent)
        }
    }
    
    private fun startVoiceService() {
        val serviceIntent = Intent(this, VoiceAssistantService::class.java)
        startForegroundService(serviceIntent)
    }
}