package com.myassist.ai.providers

import com.myassist.ai.models.ChatMessage

abstract class BaseProvider {
    abstract suspend fun generateResponse(message: String, history: List<ChatMessage>): String
    abstract fun isConfigured(): Boolean
}

class OpenAIProvider : BaseProvider() {
    override suspend fun generateResponse(message: String, history: List<ChatMessage>): String {
        // OpenAI API implementation
        return "OpenAI response to: $message"
    }
    
    override fun isConfigured(): Boolean = true
}

class AnthropicProvider : BaseProvider() {
    override suspend fun generateResponse(message: String, history: List<ChatMessage>): String {
        // Anthropic Claude API implementation
        return "Claude response to: $message"
    }
    
    override fun isConfigured(): Boolean = true
}

class GeminiProvider : BaseProvider() {
    override suspend fun generateResponse(message: String, history: List<ChatMessage>): String {
        // Google Gemini API implementation
        return "Gemini response to: $message"
    }
    
    override fun isConfigured(): Boolean = true
}

class PerplexityProvider : BaseProvider() {
    override suspend fun generateResponse(message: String, history: List<ChatMessage>): String {
        // Perplexity API implementation
        return "Perplexity response to: $message"
    }
    
    override fun isConfigured(): Boolean = true
}