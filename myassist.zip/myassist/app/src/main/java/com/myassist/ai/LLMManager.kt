package com.myassist.ai

import com.myassist.ai.models.ChatMessage
import com.myassist.ai.providers.*
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

class LLMManager {
    
    private val providers = listOf(
        OpenAIProvider(),
        AnthropicProvider(),
        GeminiProvider(),
        PerplexityProvider(),
        AmazonQProvider()
    )
    
    suspend fun getEnsembleResponse(message: String, history: List<ChatMessage>): String {
        return coroutineScope {
            val responses = providers.map { provider ->
                async {
                    try {
                        provider.generateResponse(message, history)
                    } catch (e: Exception) {
                        null
                    }
                }
            }.awaitAll().filterNotNull()
            
            if (responses.isEmpty()) {
                "I'm having trouble connecting to AI services. Please try again."
            } else {
                // Use the best response or combine them
                selectBestResponse(responses, message)
            }
        }
    }
    
    private fun selectBestResponse(responses: List<String>, query: String): String {
        // Simple selection logic - can be enhanced with ML scoring
        return when {
            query.contains("code", ignoreCase = true) -> 
                responses.find { it.contains("```") } ?: responses.first()
            query.contains("search", ignoreCase = true) || query.contains("find", ignoreCase = true) ->
                responses.maxByOrNull { it.length } ?: responses.first()
            else -> responses.first()
        }
    }
    
    suspend fun executeSystemCommand(command: String): String {
        return SystemCommandExecutor().execute(command)
    }
}